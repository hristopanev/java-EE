package domain.entities;

public enum HeroClass {

}
